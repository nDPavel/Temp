# This project is no longer being actively maintained.

[SwitchyOmega](https://github.com/FelisCatus/SwitchyOmega) is the 2.x version of switchysharp and should be used instead.
New issues should be opened for SwitchyOmega, if they are not solved during the upgrade.

SwitchyOmega has all the features of switchysharp, plus many bug fixes and improvements.
It also parses and automatically upgrades any settings backup file exported from switchysharp.

# 此项目不再维护

请使用 [SwitchyOmega](https://github.com/FelisCatus/SwitchyOmega)， switchysharp 的 2.x 升级版。
若升级后仍存在没有解决的问题，请在SwitchyOmega项目那边开启新的 issue 。

SwitchyOmega 项目支持 switchysharp 的全部功能，且包括了很多改进和修复。
SwitchyOmega 项目可以导入 switchysharp 的设置备份文件，并自动升级选项。

History
-------

The development was discontinued for project switchysharp in March 2014 in favor of SwitchyOmega.
Switchysharp was then exported from Google Code in March 2015 due to Google Code shutting down.
The full commit history and most issues are preserved and migrated to Github.


历史
----

2014年三月，switchysharp停止开发，将开发精力转移到 SwitchyOmega 项目。
2015年三月，因为 Google Code 关闭，switchysharp项目转移到Github。
所有的提交历史，以及大部分issue均已经导出到此项目以供查阅。
